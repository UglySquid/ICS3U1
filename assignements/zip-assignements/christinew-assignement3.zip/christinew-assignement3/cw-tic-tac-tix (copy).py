"""
Author: Christine Wei
Date: April 11, 2023,
Description: Improved bubble sort algorithm
"""

import random


def main():
    free_cells = 26
    ttt_board = [[" ", " ", " "], [" ", " ", " "], [" ", " ", " "], [" ", " ", " "], [" ", "R", " "], [" ", " ", " "],
                 [" ", " ", " "], [" ", " ", " "], [" ", " ", " "]]

    users_turn = first_turn()
    level = pick_level()

    while not winner(ttt_board) and (free_cells > 0):
        display_board(ttt_board)
        if users_turn:
            make_user_move(ttt_board)
            users_turn = not users_turn
        else:
            if level == 0:
                make_computer_move(ttt_board)
                users_turn = not users_turn
            elif level == 1:
                level_1(ttt_board)
                users_turn = not users_turn
            elif level == 2:
                level_2(ttt_board)
                users_turn = not users_turn
            make_user_move(ttt_board)
        free_cells -= 1

    display_board(ttt_board)

    if winner(ttt_board) == 'X':
        print("Y O U   W O N !")
        try:
            with open("HallOfFame.txt", "r") as fr:
                for line in fr:
                    print(fr.readline().strip())
        except FileNotFoundError:
            print("“No Human Has Ever Beat Me...mwah-ha-ha-ha!")
        with open("HallOfFame.txt", "a") as fa:
            fa.write(input("What is your name? "))
    elif winner(ttt_board) == 'O':
        print("I   W O N !")
    else:
        print("S T A L E M A T E !")

    print("\n*** GAME OVER ***\n")


def pick_level():
    while True:
        level = int(input("What level would you like to play? Respond with 0, 1, or 2: "))

        if level == 0 or level == 1 or level == 2:
            return level
        else:
            print("That is not a valid input")
            continue


def first_turn():
    while True:
        first = input("Would you like to go first? Respond with y or n: ")

        if first == "y" or first == "Y":
            return True
        elif first == "n" or first == "N":
            return False
        else:
            print("That is not a valid input")
            continue


def display_board(board):
    """This function accepts the Tic-Tac-Toe board as a parameter.
    It will print the Tic-Tac-Toe board grid (using ASCII characters)
    and show the positions of any X's and O's.  It also displays
    the column and row numbers on top and beside the board to help
    the user figure out the coordinates of their next move.
    This function does not return anything."""

    print("          1   2   3")
    print("         ---+---+---")
    print(f"1:     / {board[0][0]} / {board[0][1]} / {board[0][2]} /")
    print("       ---+---+---")
    print(f"2:   / {board[1][0]} / {board[1][1]} / {board[1][2]} /")
    print("     ---+---+---")
    print(f"3: / {board[2][0]} / {board[2][1]} / {board[2][2]} /")
    print("   ---+---+---")

    print("         ---+---+---")
    print(f"4:     / {board[3][0]} / {board[3][1]} / {board[3][2]} /")
    print("       ---+---+---")
    print(f"5:   / {board[4][0]} / {board[4][1]} / {board[4][2]} /")
    print("     ---+---+---")
    print(f"6: / {board[5][0]} / {board[5][1]} / {board[5][2]} /")
    print("   ---+---+---")

    print("         ---+---+---")
    print(f"7:     / {board[6][0]} / {board[6][1]} / {board[6][2]} /")
    print("       ---+---+---")
    print(f"8:   / {board[7][0]} / {board[7][1]} / {board[7][2]} /")
    print("     ---+---+---")
    print(f"9: / {board[8][0]} / {board[8][1]} / {board[8][2]} /")
    print("   ---+---+---")
    print()


def make_user_move(board):
    """This function accepts the Tic-Tac-Toe board as a parameter.
        It will ask the user for a row and column.  If the row and
        column are each within the range of 0 and 2, and that square
        is not already occupied, then it will place an 'X' in that square."""

    while True:
        try:
            while True:
                row = int(input("What row would you like to move to (1-9): ")) - 1
                col = int(input("What col would you like to move to (1-3): ")) - 1
                if (0 <= row <= 8) and (0 <= col <= 2) and (board[row][col] == " "):
                    board[row][col] = 'X'
                    return False
                else:
                    print("Sorry, invalid square. Please try again!\n")
                break
        except ValueError:
            print("Sorry, invalid square. Please try again!\n")
            continue


def make_computer_move(board):
    """This function accepts the Tic-Tac-Toe board as a parameter.
    It will randomly pick row and column values between 0 and 2.
    If that square is not already occupied it will place an 'O'
    in that square.  Otherwise, another random row and column
    will be generated."""

    while True:
        # Picks random row value and random column value
        row, column = random.randint(0, 8), random.randint(0, 2)

        # Changes the value at random position
        if board[row][column] == " ":
            board[row][column] = "O"
            break
        # Checks rows for close wins
        else:
            continue


def level_1(board):
    """
    Computer foresees the obvious path to win for itself
    and to prevent the obvious potential winner from their opponent from
    playing a bet to prevent it.
    """

    # Problem = sometimes, no spot is placed

    while True:
        # Tries to find row and column that will prevent or allow the computer to win
        row, column = close_win(board)

        # If no squares found, picks random row value and random column value
        if row is None and column is None:
            row, column = random.randint(0, 8), random.randint(0, 2)

        # Changes the value at position
        board[row][column] = "O"
        break


def level_2(board):
    # Looks for an empty square beside an already placed "O"

    # Looks for opportunities where "X" is not already placed, since that is impossible to win already

    column_squares = [[], [], []]
    for row in range(8):
        for column in range(3):
            column_squares[column].append(board[row][column])

    while True:
        # Row turn
        for row in range(8):
            for column in range(3):
                if board[row][column] == "O":
                    if " " in row and "X" not in row:
                        board[row][board.index(" ")] = "O"
                        break

        # Column turn
        for column in range(3):
            for row in range(8):
                if board[row][column] == "O":
                    if " " in column_squares[column] and "X" not in column_squares[column]:
                        board[row][board.find(" ")] = "O"
                        break

        # If no spots are found
        row, column = close_win(board)

        # If no squares found, picks random row value and random column value
        if row is None and column is None:
            row, column = random.randint(0, 8), random.randint(0, 2)

        # Changes the value at position
        board[row][column] = "O"
        break


def close_win(board):
    close_r, close_c = None, None

    # What works: Diagonals, another case when the middle is empty
    # Does not work: columns

    # Checks rows for close wins for the human player
    for row in range(9):
        if (board[row][0] == board[row][1]) and (board[row][0] != " "):
            close_r, close_c = row, 2
        elif (board[row][1] == board[row][2]) and (board[row][1] != " "):
            close_r, close_c = row, 0

    # Checks columns for close wins for the human player
    for column in range(3):
        for row in range(3):
            if (board[row][column] == board[row + 1][column]) and (board[row][column] != " "):
                close_r, close_c = row + 2, column
            if (board[row + 1][column] == board[row + 2][column]) and (board[row + 1][column] != " "):
                close_r, close_c = row, column            # if (board[row][column] == board[row + 1][column]) and (board[row][column] != " "):
                close_r, close_c = row + 2, column
            if (board[row + 1][column] == board[row + 2][column]) and (board[row + 1][column] != " "):
                close_r, close_c = row, column

    # Checks diagonals for close wins for the human player
    # Check diagonal (layer 1, top-left to bottom-right) for winner
    if (board[0][0] == board[1][1]) and (board[1][1] != " "):
        close_r, close_c = 2, 2
    if (board[1][1] == board[2][2]) and (board[1][1] != " "):
        close_r, close_c = 0, 0

    # Check diagonal (layer 2, top-left to bottom-right) for winner
    if (board[3][0] == board[4][1]) and (board[4][1] != " "):
        close_r, close_c = 5, 2
    if (board[4][1] == board[5][2]) and (board[4][1] != " "):
        close_r, close_c = 3, 0

    # Check diagonal (layer 3, top-left to bottom-right) for winner
    if (board[6][0] == board[7][1]) and (board[7][1] != " "):
        close_r, close_c = 8, 2
    if (board[7][1] == board[8][2]) and (board[7][1] != " "):
        close_r, close_c = 6, 0

    # Check diagonal (layer1, bottom-left to top-right) for winner
    if (board[0][2] == board[1][1]) and (board[1][1] != " "):
        close_r, close_c = 2, 0
    if (board[0][2] == board[1][1]) and (board[1][1] != " "):
        close_r, close_c = 0, 2

    # Check diagonal (layer2, bottom-left to top-right) for winner
    if (board[3][2] == board[4][1]) and (board[4][1] != " "):
        close_r, close_c = 5, 0
    if (board[4][1] == board[5][0]) and (board[4][1] != " "):
        close_r, close_c = 3, 2

    # Check diagonal (layer3, bottom-left to top-right) for winner
    if (board[6][2] == board[7][1]) and (board[7][1] != " "):
        close_r, close_c = 8, 0
    if (board[7][1] == board[8][0]) and (board[7][1] != " "):
        close_r, close_c = 7, 1

    # Check verticals for close wins for the human player
    for row in range(3):
        for column in range(3):
            if (board[row][column] == board[row + 3][column]) and (board[row + 3][column] != " "):
                close_r, close_c = row + 6, column
            elif (board[row + 3][column] == board[row + 6][column]) and (board[row + 3][column] != " "):
                close_r, close_c = row, column

    return close_r, close_c


def winner(board):
    """This function accepts the Tic-Tac-Toe board as a parameter.
    If there is no winner, the function will return the empty string "".
    If the user has won, it will return 'X', and if the computer has
    won it will return 'O'."""

    # Check rows for winner
    for row in range(9):
        if (board[row][0] == board[row][1] == board[row][2]) and (board[row][0] != " "):
            return board[row][0]

    # Check columns for winner
    for column in range(3):
        if (board[0][column] == board[1][column] == board[2][column]) and (board[0][column] != " "):
            return board[0][column]
        elif (board[3][column] == board[4][column] == board[5][column]) and (board[3][column] != " "):
            return board[3][column]
        elif (board[6][column] == board[7][column] == board[8][column]) and (board[6][column] != " "):
            return board[6][column]

    for column in range(3):
        for row in range(3, 3):
            if (board[row][column] == board[row+1][column] == board[row+2][column]) and (board[row][column] != " "):
                return board[row][column]

    # Check diagonal (layer 1, top-left to bottom-right) for winner
    if (board[0][0] == board[1][1] == board[2][2]) and (board[0][0] != " "):
        return board[0][0]

    # Check diagonal (layer 2, top-left to bottom-right) for winner
    if (board[3][0] == board[4][1] == board[5][2]) and (board[3][0] != " "):
        return board[3][0]

    # Check diagonal (layer 3, top-left to bottom-right) for winner
    if (board[6][0] == board[7][1] == board[8][2]) and (board[6][0] != " "):
        return board[6][0]

    # Check diagonal (layer1, bottom-left to top-right) for winner
    if (board[0][2] == board[1][1] == board[2][0]) and (board[0][2] != " "):
        return board[0][2]

    # Check diagonal (layer2, bottom-left to top-right) for winner
    if (board[3][2] == board[4][1] == board[5][0]) and (board[3][2] != " "):
        return board[3][2]

    # Check diagonal (layer3, bottom-left to top-right) for winner
    if (board[6][2] == board[7][1] == board[8][0]) and (board[3][2] != " "):
        return board[6][2]

    # Check wins that pass through all three layers
    for row in range(3):
        for column in range(3):
            if (board[row][column] == board[row+3][column] == board[row+6][column]) and (board[row+6][column] != " "):
                return board[row][column]

    # No winner: return the empty string
    return ""


# start game
main()
